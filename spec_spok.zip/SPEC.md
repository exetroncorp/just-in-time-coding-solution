# SPOC Validator — Spécification complète

> **Objet de ce document.** Spécification autosuffisante du système « SPOC Validator » :
> elle décrit tout ce qu'il faut pour reconstruire l'application de zéro, sans accès au
> code existant, et sert de référentiel d'évaluation (benchmark). Chaque exigence porte
> un identifiant (`[XX-n]`) ; la conformité d'une implémentation se mesure exigence par
> exigence, puis sur les scénarios de la section 15.
>
> **Stack de référence** (recommandée, non imposée) : Python 3.12, FastAPI, SQLAlchemy 2,
> Jinja2, itsdangerous, ldap3, httpx, uvicorn. Toute stack convient si les comportements
> observables (HTTP, HTML, JSON, CSV, e-mails, base) sont respectés.
>
> Dernière mise à jour : 2026-11-05 · 227 tests dans l'implémentation de référence.
>
> **Schéma du workflow** : [`spec/workflow.html`](workflow.html) — diagramme façon
> Excalidraw du parcours d'une demande (§ 3–5), fichier HTML autosuffisant (aucune
> ressource externe) à ouvrir dans un navigateur.

---

## 1. Mission

Moteur de **validation des demandes d'accès produit** par des SPOC (Single Point of
Contact). Les demandes sont **soumises par une application externe** (portail de
demande) via une API REST. Le système :

1. connaît, pour chaque **produit** et chaque **équipe**, le **mode de validation**
   (validation par SPOC, ou approbation automatique) et la liste des SPOC ;
2. à chaque demande, **notifie par e-mail** le(s) SPOC concerné(s) avec des liens de
   décision signés, ou approuve automatiquement ;
3. enregistre la **décision** (approbation/refus/expiration) et, en cas d'approbation,
   **déclenche l'attribution de licence** (port d'intégration) ;
4. offre une **UI web d'administration** (SPOC, modes, templates d'e-mail, produits,
   équipes, droits) et de **suivi** ;
5. expose le tout à l'application externe (statuts, catalogue, SPOC par équipe).

- [GEN-1] La soumission de demandes ne se fait **jamais** depuis l'UI du système :
  uniquement par l'API (`POST /api/requests`).
- [GEN-2] Tous les textes visibles (UI, mails, erreurs) sont en **français accentué**.
- [GEN-3] L'application démarre d'un seul process (`uvicorn main:app`) ; aucun service
  annexe n'est requis (pas de worker, pas de cron externe : voir expiration [WF-20]).

---

## 2. Concepts et modèle de données

### 2.1 Entités

| Entité | Champs (contraintes) |
|---|---|
| **User** | id, email (unique, normalisé minuscule), display_name, is_superadmin (bool) |
| **Product** | id, name (unique, ≤ 80), description (≤ 300, optionnelle) |
| **Team** | id, name (unique, ≤ 80). Les équipes sont **partagées par tous les produits** |
| **SpocAssignment** | id, product_id, team_id, spoc_email, spoc_name (≤ 120) ; **unicité (product, team, email)** |
| **AutoApprovalRule** | (product_id, team_id) unique : présence = approbation automatique pour ce couple |
| **AccessRequest** | id, product_id, team_id, requester_email, requester_name (≤ 120), justification (≤ 2000, multiligne), status, created_at (UTC), decided_at, decided_by (e-mail), decision_comment (≤ 1000), token_id (jeton de demande, 32 hex, conservé après décision) |
| **EmailTemplate** | id, product_id (NULL = template par défaut, unique par produit), subject (≤ 250), html_body (≤ 50 000) |
| **ProductAdmin** | (user_id, product_id) unique |
| **LicenseGrant** | id, request_id, product_id, grantee_email, granted_at (UTC) |

- [DATA-1] Statuts d'une demande : `pending` → `approved` \| `rejected` \| `expired`.
  Aucune autre transition (une demande décidée ou expirée est immuable).
- [DATA-2] **Une seule demande `pending`** par (requester_email, product, team), garantie
  **en base** par un index unique partiel (`WHERE status = 'pending'`), supporté par
  SQLite et PostgreSQL — pas seulement par un contrôle applicatif.
- [DATA-3] Le **mode de validation est porté par le couple (produit, équipe)** : une même
  équipe peut être en auto-approbation sur un produit et en validation SPOC sur un autre.
  L'absence de règle = validation SPOC (défaut).
- [DATA-4] Toutes les dates sont stockées en **UTC** (timezone-aware).
- [DATA-5] Suppression de produits, d'équipes et de demandes : **hors périmètre**
  (l'historique les référence). Les SPOC et les droits d'admin, eux, se retirent.
- [DATA-6] Validation des saisies, appliquée **dans la couche métier** (pas seulement
  dans l'UI) : bornes du tableau ci-dessus, e-mail ≤ 254 au format `x@y.tld` normalisé
  en minuscules, espaces de bordure retirés, **caractères de contrôle refusés**
  (`\x00-\x1f`, `\x7f` ; les champs multilignes tolèrent `\n`, `\r`, `\t`). Les messages
  d'erreur sont affichables tels quels.

### 2.2 Rôles et droits

| Rôle | Attribution | Droits |
|---|---|---|
| **Application externe** | clé d'API (`X-API-Key`) | créer une demande, lire un statut, lire catalogue et SPOC |
| **SPOC** | désigné par un admin produit (aucun compte requis) | approuver/refuser **via le lien signé reçu par e-mail**, avec commentaire optionnel |
| **Utilisateur connecté** | SSO/LDAP (ou dev) | tableau de bord : **ses propres demandes** (rapprochées par e-mail) |
| **Admin produit** | nommé par un superadmin, par produit | pour **ses** produits : SPOC par équipe, mode de validation par équipe, template d'e-mail, consultation/recherche des demandes, export/import CSV ; plus : créer/renommer des équipes (partagées) |
| **Superadmin** | `SUPERADMIN_EMAILS` (source de vérité) ou seed | tout admin produit sur **tous** les produits + créer/éditer les produits + nommer/révoquer les admins produit + voir la liste des superadmins |

- [ROLE-1] Les autorisations sont vérifiées **dans la couche métier (cas d'usage)**, pas
  uniquement dans les routes : un appel direct de la logique avec un acteur non autorisé
  lève une erreur d'autorisation.
- [ROLE-2] Un utilisateur sans rôle d'admin reçoit **403** sur toutes les pages
  d'administration (produits, équipes, accès, imports/exports).
- [ROLE-3] Un admin produit reçoit **403** sur les pages/actions d'un produit qu'il
  n'administre pas, et sur les actions réservées au superadmin (création/édition de
  produit, gestion des admins, page Paramètres d'un produit).
- [ROLE-4] Gestion des équipes (créer, renommer) : superadmin **et** tout utilisateur
  administrant au moins un produit.
- [ROLE-5] Un admin produit reste un demandeur ordinaire : son tableau de bord liste les
  demandes dont il est **demandeur**, indépendamment de ses produits.

---

## 3. Workflow des demandes

### 3.1 Soumission (API)

À `POST /api/requests` (produit, équipe, demandeur, justification) :

- [WF-1] Produit ou équipe inconnus (comparaison sur le **nom exact**) → 404, rien n'est créé.
- [WF-2] Les champs sont validés selon [DATA-6] → 400 sinon.
- [WF-3] Si le couple (produit, équipe) exige la validation SPOC et qu'**aucun SPOC**
  n'est déclaré → 422, rien n'est créé, message invitant à contacter l'admin du produit.
- [WF-4] S'il existe déjà une demande `pending` du même demandeur sur le même couple :
  - si elle est **périmée** (créée il y a plus de `TOKEN_TTL_HOURS`), elle passe
    d'abord à `expired` (avec le commentaire d'expiration [WF-21]) et ne bloque plus ;
  - sinon → **409** « Une demande est déjà en attente… ».
- [WF-5] La demande est créée avec un **jeton de demande** aléatoire (`token_id`,
  32 caractères hexadécimaux) qui sera embarqué dans les liens de **tous** ses SPOC.
- [WF-6] **Couple en auto-approbation** : la demande passe immédiatement à `approved`,
  `decided_by = auto@spoc-validator.local`, commentaire « Validation automatique :
  équipe en auto-approbation pour ce produit » ; une `LicenseGrant` est enregistrée et
  le provisioner appelé ; **aucun e-mail** n'est envoyé. La réponse porte
  `auto_approved: true`. L'auto-approbation fonctionne même sans aucun SPOC déclaré.
- [WF-7] **Couple en validation SPOC** : un e-mail est envoyé à **chaque** SPOC du
  couple, rendu depuis le template du produit (sinon le template par défaut, sinon le
  template codé en dur), avec trois liens signés : `approve_url`
  (`{BASE_URL}/validate/{token}?decision=approve`), `reject_url` (`…?decision=reject`),
  `review_url` (`…/validate/{token}`).
- [WF-8] Si **l'envoi d'un e-mail échoue**, la transaction est annulée : **aucune
  demande n'est enregistrée**, l'API répond **502** avec un message explicite
  (« réessayez plus tard »). Jamais de demande orpheline sans SPOC notifié.
- [WF-9] Journal d'audit applicatif (logger dédié) : soumission, auto-approbation,
  décision, expiration, et toutes les actions d'administration (qui, quoi).

### 3.2 Décision du SPOC (liens signés)

- [WF-10] Le token des liens est **signé** (HMAC, implémentation de référence :
  `itsdangerous.URLSafeTimedSerializer`, salt constant) et porte : id de la demande,
  e-mail du SPOC destinataire, jeton de la demande (`token_id`). Il **expire** après
  `TOKEN_TTL_HOURS` (défaut 72 h). Un token de plus de 1024 caractères est rejeté sans
  tentative de décodage.
- [WF-11] `GET /validate/{token}` **n'a aucun effet de bord** (les scanners d'e-mail ne
  déclenchent rien) : la page affiche la demande (demandeur, produit, équipe, date,
  justification), un champ commentaire et deux boutons Approuver / Refuser. Le paramètre
  `?decision=approve|reject` ne fait que **pré-sélectionner** visuellement le choix.
  La décision est un **POST** (protégé par CSRF de session).
- [WF-12] Un lien est refusé (page d'erreur 403 dédiée, sans fuite d'information) si :
  signature invalide ou expirée, demande inexistante, **jeton de demande différent**
  de `token_id` (liens d'une autre demande), ou — tant que la demande est `pending` —
  si le destinataire **n'est plus SPOC** du couple (retirer un SPOC désactive ses liens
  en attente). Message spécifique dans ce dernier cas.
- [WF-13] Après décision, les liens restent **consultables** : ils affichent l'état réel
  (page « déjà traitée » montrant la décision), mais ne permettent plus de décider
  (tentative → 409 avec l'état affiché).
- [WF-14] **Premier SPOC qui statue gagne** : l'écriture de la décision est un
  **compare-and-set atomique** en base (`UPDATE … WHERE status='pending'`). Deux
  validations simultanées ⇒ **une seule** décision et **une seule** licence.
- [WF-15] Approbation ⇒ `LicenseGrant` + appel du port `LicenseProvisioner`
  (implémentation par défaut : journalisation ; point d'intégration du SI licensing).
  Refus ⇒ rien n'est attribué.
- [WF-16] Le commentaire du SPOC (≤ 1000, multiligne) est validé [DATA-6] ; en cas de
  saisie invalide l'utilisateur est renvoyé sur la page avec le message d'erreur.
- [WF-17] Demandes antérieures à l'introduction du jeton de demande (token_id NULL en
  base) : leurs liens signés restent capables d'**afficher** une demande déjà traitée,
  mais jamais de décider (si `pending`, lien refusé).

### 3.3 Expiration automatique

- [WF-20] Un **balayage** passe à `expired` toute demande `pending` plus vieille que
  `TOKEN_TTL_HOURS`. Il s'exécute dans le process web, **au plus une fois par minute et
  par process**, déclenché par les requêtes (pages admin, lecture de statut API), dans
  une **transaction dédiée** : son échec (base verrouillée…) n'empêche jamais de servir
  la page, et sera retenté à l'intervalle suivant.
- [WF-21] Une demande expirée porte `decided_at` et le commentaire exact : « Expirée :
  aucune décision avant l'expiration des liens de validation ». Le demandeur peut alors
  soumettre une nouvelle demande ([WF-4]).

---

## 4. API externe (contrat)

Préfixe `/api`. Authentification : en-tête **`X-API-Key`**.

- [API-1] Clés configurées par `API_KEYS` (liste séparée par virgules, une par
  intégration). Comparaison en **temps constant**. Sans clé configurée → **503** ;
  clé absente ou inconnue → **401**.
- [API-2] Les erreurs de l'API sont en **JSON** (`{"detail": …}`), y compris celles
  issues des handlers globaux (403/404/409/500), tandis que l'UI rend des pages HTML.
  Le sélecteur : chemin commençant par `/api/` (plus `/dev/outbox.json`).

### 4.1 `POST /api/requests` → 201

Entrée (JSON, bornes appliquées) :

```json
{"product": "CLAUDE CODE", "team": "Team Backend",
 "requester_email": "jean.dupont@example.com",
 "requester_name": "Jean Dupont",
 "justification": "Projet Phoenix"}
```

Sortie 201 (même forme pour `GET /api/requests/{id}`) :

```json
{"id": 12, "product": "CLAUDE CODE", "team": "Team Backend",
 "requester_email": "jean.dupont@example.com", "status": "pending",
 "created_at": "2026-11-05T09:12:33Z", "decided_at": null,
 "decided_by": null, "decision_comment": "", "auto_approved": false}
```

- [API-3] Codes : **201** créé (ou auto-approuvé : `status="approved"`,
  `auto_approved=true`) ; **400** validation ; **404** produit/équipe inconnu ;
  **409** doublon en attente ; **422** aucun SPOC configuré ; **502** échec d'envoi
  du mail (rien n'est enregistré).
- [API-4] `auto_approved` est vrai si et seulement si `decided_by` est l'adresse de
  l'auto-approbation (`auto@spoc-validator.local`).

### 4.2 `GET /api/requests/{id}` → 200 | 404

- [API-5] Lecture du statut (polling). La lecture **déclenche le balayage
  d'expiration** [WF-20] : une demande périmée est vue `expired`, pas `pending`.

### 4.3 `GET /api/catalog` → 200

```json
{"products": ["CLAUDE CODE", "DEVX"],
 "teams": [{"name": "Team Backend"}, {"name": "Team QA"}],
 "auto_approval": {"CLAUDE CODE": ["Team QA"], "DEVX": ["Team QA", "Team Plateforme"]}}
```

- [API-6] `auto_approval` donne, **par produit**, les noms d'équipes en approbation
  automatique (reflet exact de [DATA-3]).

### 4.4 `GET /api/spocs[?product=NOM]` → 200 | 404

```json
{"products": [{"product": "CLAUDE CODE", "teams": [
   {"team": "Team Backend", "requires_validation": true,
    "spocs": [{"name": "Grace Hopper", "email": "grace.hopper@example.com"}]},
   {"team": "Team QA", "requires_validation": false, "spocs": []}]}]}
```

- [API-7] Toutes les équipes apparaissent pour chaque produit (même sans SPOC) avec
  `requires_validation` du couple. `?product=` inconnu → 404.

---

## 5. E-mails

- [MAIL-1] Deux modes : `EMAIL_MODE=console` (dev : mails capturés en mémoire, 50
  derniers, exposés sur `/dev/outbox*`) et `smtp` (production).
- [MAIL-2] **Templates** : un template par défaut (product_id NULL) + un template
  optionnel par produit (prioritaire). Repli final sur un template codé en dur.
  Placeholders autorisés (liste blanche stricte, `{{cle}}`) :
  `requester_name, requester_email, product_name, team_name, justification,
  spoc_name, approve_url, reject_url, review_url`. Tout autre placeholder est
  **refusé à l'enregistrement** avec un message listant les autorisés.
- [MAIL-3] Le corps doit contenir **au moins un lien de décision**
  (`approve_url`, `reject_url` ou `review_url`) — refus sinon.
- [MAIL-4] **Rendu sûr, sans moteur de template** sur le contenu utilisateur (pas de
  SSTI) : simple substitution. Dans le **corps**, les valeurs sont échappées HTML
  (les `*_url` échappées pour attribut). Dans le **sujet**, les sauts de ligne de
  toute valeur sont neutralisés (anti-injection d'en-têtes SMTP).
- [MAIL-5] Envoi SMTP : message **multipart/alternative** (version texte générée
  automatiquement depuis le HTML, liens http(s) conservés en clair), en-têtes `Date`,
  `Message-ID` (domaine de l'expéditeur), `Auto-Submitted: auto-generated`,
  `X-Auto-Response-Suppress: All`. Un en-tête invalide (saut de ligne dans le sujet…)
  est refusé **avant** l'envoi. TLS : implicite (`SMTP_SSL=1`) ou STARTTLS (défaut),
  **certificat vérifié** ; dérogation explicite `SMTP_ALLOW_PLAINTEXT=1`.
  Toute erreur d'envoi devient une erreur typée que l'appelant traduit ([WF-8]).
- [MAIL-6] Le template par défaut (fourni dans le seed et en repli) présente :
  en-tête sombre « SPOC Validator / Validation d'accès requise », salutation au nom du
  SPOC, qui demande quoi pour quelle équipe, bloc justification, boutons **Approuver**
  / **Refuser**, lien « Examiner la demande avant de décider », note expliquant que
  chaque bouton ouvre une page de confirmation, que le lien est personnel et expire.

---

## 6. UI web — structure générale

### 6.1 Navigation et écrans

| Route | Accès | Contenu |
|---|---|---|
| `GET /login`, `POST /login`, `GET /auth/oidc`, `GET /auth/callback`, `POST /logout` | public | connexion selon `AUTH_MODE` (§ 7) |
| `GET /` | connecté | tableau de bord : compteurs de **mes demandes** par statut, liste de mes demandes, et si admin : synthèse de mes produits |
| `GET /validate/{token}`, `POST /validate/{token}` | lien signé | page de décision SPOC (§ 3.2) |
| `GET /admin` | admin | **redirige** (303) vers `/admin/products` |
| `GET /admin/products` | admin | liste des produits administrés : logo, nom, nb SPOC, équipes bloquées, demandes en attente, admins (vue superadmin) ; bouton « Nouveau produit » (superadmin) |
| `GET /admin/products/{id}` | admin du produit | onglet **Validation** : tableau une ligne par équipe → mode (badge + bascule), SPOC en chips (avatar, nom, e-mail, retrait), ajout par modale ; export/import CSV ; bandeau d'alerte si équipes bloquées |
| `GET /admin/products/{id}/requests` | admin du produit | onglet **Demandes** : filtres par statut (segmented avec compteurs), **recherche serveur** (`q`), **pagination 50/page**, justification repliée au-delà de 90 caractères |
| `GET/POST /admin/products/{id}/template`, `POST …/template/reset`, `GET …/template/preview` | admin du produit | onglet **Template e-mail** : éditeur sujet+corps, liste des placeholders, aperçu sur données fictives, bouton « rétablir le défaut » (visible si personnalisé) ; une erreur de validation **réaffiche le brouillon** saisi (status 400) sans le perdre |
| `GET /admin/products/{id}/settings` | **superadmin** | onglet **Paramètres** : éditer nom/description, liste des admins du produit, nommer/révoquer (retour sur la page d'origine via champ `next` filtré) |
| `GET /admin/teams`, `POST /admin/teams`, `POST /admin/teams/{id}/rename` | admin ou superadmin | équipes : création, renommage (modale pré-remplie), nb de SPOC (tous produits), produits où l'équipe est en auto |
| `POST /admin/products/{id}/teams/{tid}/validation` | admin du produit | bascule du mode (`mode=spoc|auto`) pour **ce produit** ; confirmation avant passage en auto |
| `POST /admin/products/{id}/spocs`, `POST /admin/spocs/{aid}/delete` | admin du produit | ajout / retrait de SPOC (confirmation au retrait, mention de la désactivation des liens) |
| `GET /superadmin` | superadmin | page **Accès** : affectations admin⇄produit triées, liste des superadmins, bannière si les superadmins sont pilotés par `SUPERADMIN_EMAILS` |
| `POST /superadmin/products`, `POST /superadmin/products/{id}/edit`, `POST /superadmin/admins`, `POST /superadmin/admins/revoke` | superadmin | création de produit (**redirige vers ses Paramètres**), édition, droits |
| export/import CSV (§ 8) | admin | `GET /admin/products/{id}/spocs/export.csv`, `GET /admin/spocs/export.csv`, `POST …/spocs/import` (aperçu), `POST …/spocs/import/apply` |
| `GET /dev/outbox`, `/dev/outbox.json`, `/dev/outbox/{i}` | DEBUG + console | boîte d'envoi simulée (page, JSON filtrable par `?to=`, corps HTML brut isolé) |
| `GET /healthz`, `GET /readyz` | public | liveness (process) / readiness (**SELECT 1** sur la base, 503 sinon) |

- [UI-1] Chaque produit a un **en-tête commun** : fil d'Ariane (Produits / nom), logo,
  nom, méta-ligne (nb SPOC ; « N équipes sans SPOC » en rouge cliquable, ou « Toutes
  les équipes couvertes » ; « N demandes en attente » cliquable vers l'onglet filtré),
  puis des **onglets soulignés** : Validation · Demandes (badge si en attente) ·
  Template e-mail · Paramètres (superadmin seulement).
- [UI-2] **Équipe bloquée** = validation SPOC requise pour ce produit mais aucun SPOC :
  signalée en rouge partout (liste produits, en-tête, bandeau de l'onglet Validation,
  ligne du tableau) avec le texte expliquant que les demandes seront refusées.
- [UI-3] Toute action d'écriture UI est un **POST + redirection 303** avec message
  **flash** (succès ou erreur) affiché sur la page suivante ; exceptions : l'éditeur de
  template qui ré-affiche le brouillon en 400 [UI tableau], et les aperçus d'import.
- [UI-4] Les listes tabulaires sont des **tableaux** (jamais des grilles de cartes) ;
  les créations/éditions passent par des **modales** (`<dialog>`) ; confirmation des
  actions destructives par **boîte de dialogue custom** (repli `window.confirm`),
  avec titre, message contextuel (noms réels) et bouton d'action nommé.
- [UI-5] **Aucun JavaScript inline ni attribut `style`** (hors SVG des logos) : la CSP
  l'interdit. JS en fichiers statiques : comportements génériques (modales avec
  pré-remplissage via `data-*`, confirmations, lignes cliquables, menu mobile,
  fermeture des flashs), tri/filtre client des tableaux (quand activé), éditeur de
  template (aperçu). **Aucune ressource externe** (polices ou CDN) : tout est servi
  par l'application.
- [UI-6] **Thèmes** : 7 (clair — défaut, sombre, aurora, néon, forest, sunset, mono),
  appliqués par `data-theme` sur `<html>` avant le premier rendu, persistés en
  `localStorage`, sélecteur à pastilles. Tout le style est en variables CSS.
- [UI-7] **Logos produits** : SVG inline générés par nom (marques distinctives pour
  IBM BOB / CLAUDE CODE / DEVX / I4DEVA, monogramme à défaut), ids SVG **uniques par
  occurrence** (générateur `uid()`), sinon un dégradé masqué casse les autres logos.
- [UI-8] **Dates affichées** dans le fuseau `APP_TIMEZONE` (défaut Europe/Paris) au
  format `15/10/2026 21:46` (variante « 15/10/2026 à 21:46 ») via des filtres de
  template dédiés ; jamais de `strftime` brut dans les vues. Stockage UTC [DATA-4].
- [UI-9] Accessibilité : `aria-current` sur l'onglet/filtre actif, `aria-sort` sur les
  tris, labels sur les champs et boutons icônes, `role="search"`, focus visible,
  `prefers-reduced-motion` respecté.
- [UI-10] Pages d'erreur HTML uniformes par code (400, 401, 403, 404, 405, 409, 413,
  429, 500, 502, 503) avec titre/message français ; le détail métier est affiché quand
  il est sûr, les messages génériques le remplacent sinon. Un échec CSRF affiche une
  page « Session expirée » pédagogique. Les erreurs 500 sont rendues même sans session.
- [UI-11] L'onglet Demandes : compteur « total filtré / total » quand un filtre est
  actif, état vide avec bouton « Réinitialiser les filtres », pagination affichant
  « a–b sur n » et Précédentes/Suivantes (page hors bornes ⇒ dernière page).
- [UI-12] Le tableau de bord d'un demandeur sans demande explique que les demandes se
  font depuis le portail de demande d'accès.

---

## 7. Authentification UI et sessions

- [AUTH-1] `AUTH_MODE` : `dev` (sélecteur d'utilisateur ; **refusé si DEBUG≠1**),
  `ldap`, `oidc`.
- [AUTH-2] **Sessions** : cookie signé (`SessionMiddleware`), nom `spoc_session`,
  `SameSite=Lax`, `Secure` hors DEBUG, durée 8 h. À la connexion la session est
  **réinitialisée** (anti-fixation) puis reçoit l'id utilisateur et un **jeton CSRF**
  aléatoire (32 octets urlsafe).
- [AUTH-3] **CSRF** : tout POST de l'UI (y compris login/logout et décision SPOC)
  porte un champ `_csrf` comparé en temps constant au jeton de session → 403 sinon.
- [AUTH-4] Accès à une page protégée sans session → redirection 303 vers `/login`, et
  retour après connexion sur la page demandée (GET seulement). Le chemin de retour est
  filtré : relatif, commençant par `/`, sans `//` ni `\`, ≤ 512, jamais `/login*` ;
  sinon `/` (pas de redirection ouverte).
- [AUTH-5] **LDAP** : recherche du DN (compte de service optionnel) avec **filtre
  échappé**, puis bind avec les identifiants fournis ; attributs mail/displayName/cn ;
  timeouts courts ; **certificat vérifié** (ldaps:// ou StartTLS — ldap3 ne vérifie
  rien par défaut, l'implémentation doit l'exiger). Échecs → message générique.
- [AUTH-6] **Anti force brute** (LDAP) : 5 échecs par identifiant sur 15 min ⇒ blocage
  jusqu'à expiration de la fenêtre avec message d'attente ; mémoire bornée
  (10 000 clés max) ; un succès réinitialise le compteur.
- [AUTH-7] **OIDC** : découverte `.well-known/openid-configuration`, code flow avec
  `state` (session, comparé en temps constant) **et PKCE S256** ; échange du code puis
  `userinfo` (e-mail requis) ; annulation/erreur du fournisseur → retour login avec
  message, sans trace technique.
- [AUTH-8] À la connexion, l'utilisateur local est créé s'il n'existe pas ; en mode
  LDAP/OIDC son nom d'affichage est **mis à jour** depuis l'annuaire (normalisé : une
  ligne, ≤ 120). Un e-mail invalide renvoyé par l'IdP → erreur propre.
- [AUTH-9] **Superadmins pilotés** : au démarrage, si `SUPERADMIN_EMAILS` est non vide,
  la liste fait foi — adresses promues (comptes créés au besoin), tout superadmin hors
  liste **rétrogradé** ; liste vide = aucun changement. Démarrage concurrent de
  plusieurs replicas toléré (reprise sur conflit d'insertion).

---

## 8. Import / export CSV des SPOC

Objet : sauvegarder/transférer la **configuration de validation** (équipes, mode,
SPOC), par produit ou pour tous les produits administrés.

- [CSV-1] **Export produit** `GET /admin/products/{id}/spocs/export.csv` : colonnes
  `Équipe;Mode;Nom du SPOC;E-mail du SPOC`. **Export global** `GET
  /admin/spocs/export.csv` : colonne `Produit` en tête, limité aux produits
  administrés. Nom de fichier : `spoc-<slug>-<AAAAMMJJ>.csv`.
- [CSV-2] Format d'export : séparateur `;`, **BOM UTF-8**, fins de ligne CRLF
  (ouverture directe dans Excel FR). Une ligne par SPOC **et une ligne par équipe sans
  SPOC** (pour transporter son mode). Mode : `spoc` ou `auto`.
- [CSV-3] **Anti-injection de formules** : toute valeur commençant par `=`, `+`, `-`,
  `@`, tab ou CR est préfixée d'une apostrophe à l'export ; l'import retire ce préfixe
  (aller-retour sans perte).
- [CSV-4] **Import tolérant** : UTF-8 (avec/sans BOM) ou Windows-1252 ; séparateur
  détecté (`;`, `,` ou tab) ; en-têtes reconnus par alias insensibles aux accents/à la
  casse (ex. `equipe`, `Mode de validation`, `E-mail du SPOC`, `courriel`…). Seule la
  colonne Équipe est obligatoire. Valeurs de mode acceptées : `spoc`, `validation`,
  `auto`, `automatique`, « auto-approbation »… Lignes vides ignorées. Fichier ≤ 500 ko
  et ≤ 2000 lignes. Erreurs rapportées **avec le numéro de ligne**.
- [CSV-5] **Deux temps** : (1) dépôt du fichier → **aperçu** du plan (équipes à créer,
  SPOC ajoutés, SPOC retirés si mode remplacement, modes modifiés, erreurs) — rien
  n'est écrit ; (2) confirmation → le contenu est **re-analysé et re-vérifié** (droits
  compris) avant application. Un fichier contenant des erreurs ne peut jamais être
  appliqué (l'application est refusée avec flash explicite).
- [CSV-6] Mode **remplacement** (case à cocher) : retire les SPOC absents du fichier,
  mais **seulement dans les équipes listées** dans le fichier.
- [CSV-7] Import depuis la page d'un produit : la colonne Produit est facultative ;
  une ligne pour un **autre** produit est une erreur. Import global : chaque ligne doit
  nommer un produit existant **que l'acteur administre** (sinon erreur sur la ligne).
  Les équipes inconnues sont créées (une fois, partagées).
- [CSV-8] Modes contradictoires pour une même équipe dans le fichier (spoc **et**
  auto) : erreur. Le plan appliqué journalise les compteurs (ajoutés/retirés/modes/
  équipes créées) et le flash de succès les détaille.

---

## 9. Sécurité (exigences transverses)

- [SEC-1] **En-têtes sur toutes les réponses** :
  `X-Content-Type-Options: nosniff`, `Referrer-Policy: same-origin`,
  `X-Frame-Options: DENY`, `Cross-Origin-Opener-Policy: same-origin`,
  `Cross-Origin-Resource-Policy: same-origin`, `Permissions-Policy`
  (camera, microphone, geolocation, payment, usb désactivés),
  `X-Robots-Tag: noindex, nofollow`, et hors DEBUG
  `Strict-Transport-Security: max-age=31536000; includeSubDomains`.
- [SEC-2] **CSP** : `default-src 'self'; script-src 'self'; style-src 'self'
  'unsafe-inline'; img-src 'self' data: https:; font-src 'self'; connect-src 'self';
  frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self';
  object-src 'none'`. Les aperçus HTML de mails (iframe plein écran et outbox dev)
  imposent leur propre CSP durcie : `default-src 'none'; style-src 'unsafe-inline';
  img-src data: https:` + `sandbox` (aucun script).
- [SEC-3] **Cache** : pages et API `Cache-Control: no-store` ; fichiers statiques
  versionnés par empreinte (`?v=<hash du contenu>`) et cachés 7 jours hors DEBUG
  (`no-cache` en DEBUG). L'empreinte change à chaque modification d'un fichier.
- [SEC-4] **Limite de taille du corps** : 1 Mo. Refus en **413** dès l'en-tête
  `Content-Length`, ou en cours de lecture pour un corps chunké ; page HTML propre pour
  l'UI, JSON pour l'API (les middlewares sont ASGI purs pour que l'erreur levée pendant
  la lecture du corps soit bien transformée, pas avalée).
- [SEC-5] Uploads CSV : re-bornés à 500 ko / 2000 lignes [CSV-4] indépendamment de la
  limite globale.
- [SEC-6] Transactions : le commit a lieu **avant l'envoi de la réponse** (une réponse
  201/200 ne part jamais si l'écriture échoue ensuite).
- [SEC-7] Recherche des demandes : motifs `%`/`_` de l'utilisateur **échappés** (pas de
  wildcard involontaire) ; `q` tronqué à 100 caractères ; page ≥ 1.
- [SEC-8] Garde-fous de **configuration en production** (DEBUG≠1) — l'application
  **refuse de démarrer** si : `SECRET_KEY` < 32 caractères ou valeur d'exemple
  (« changez-moi »…) ; une clé d'API < 24 caractères ou d'exemple ; `BASE_URL` non
  https ; `EMAIL_MODE` ≠ smtp ; SMTP sans TLS (sauf dérogation explicite) ; LDAP en
  clair sans StartTLS ; `OIDC_ISSUER` non https ; `AUTH_MODE=dev` ; `SEED_ON_STARTUP=1`.
  En DEBUG : `SECRET_KEY` générée au vol, clé d'API de dev `dev-api-key`.
- [SEC-9] `TOKEN_TTL_HOURS` borné [1, 720] ; entiers d'environnement invalides →
  erreur de démarrage explicite ; `BASE_URL` : slash final retiré, schéma requis ;
  identifiants PostgreSQL **URL-encodés** dans l'URL de connexion.
- [SEC-10] Les routes `/dev/*` n'existent que si `DEBUG=1` **et**
  `EMAIL_MODE=console` (404 sinon). L'outbox est en mémoire (vidée au redémarrage).
- [SEC-11] Journalisation : connexions (succès/échec, mode), actions d'administration
  et décisions (audit), erreurs non gérées avec stack ; jamais de secret ni de token
  dans les logs. Logs d'échec LDAP tronqués (pas d'identifiant arbitraire long).
- [SEC-12] L'UI ne révèle jamais si un lien de validation correspond à une demande
  réelle au-delà du nécessaire (messages d'erreur neutres), et les pages porteuses de
  jetons ne sont jamais indexables ni mises en cache ([SEC-1], [SEC-3]).

---

## 10. Configuration (variables d'environnement)

| Variable | Défaut | Rôle |
|---|---|---|
| `DEBUG` | `0` | mode développement (déverrouille dev/console/seed) |
| `SECRET_KEY` | généré si DEBUG | signature sessions + liens ([SEC-8]) |
| `BASE_URL` | `http://localhost:8000` | URL publique absolue des liens d'e-mail |
| `APP_TIMEZONE` | `Europe/Paris` | fuseau d'affichage [UI-8] (repli UTC si inconnu) |
| `DB_BACKEND` | `sqlite` | `sqlite` \| `postgres` |
| `SQLITE_PATH` | `data/spoc.db` | fichier SQLite (dossier créé) |
| `DATABASE_URL` | — | URL SQLAlchemy prioritaire |
| `POSTGRES_HOST/PORT/DB/USER/PASSWORD` | localhost/5432/spoc/spoc/— | connexion PG |
| `AUTH_MODE` | `dev` | `dev` \| `ldap` \| `oidc` |
| `LDAP_URL`, `LDAP_BASE_DN`, `LDAP_USER_FILTER` (`(uid={username})`), `LDAP_BIND_DN`, `LDAP_BIND_PASSWORD`, `LDAP_START_TLS` | — | annuaire |
| `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET` | — | SSO |
| `EMAIL_MODE` | `console` | `console` \| `smtp` |
| `SMTP_HOST/PORT/USER/PASSWORD/FROM` | localhost/587/—/—/noreply@example.com | envoi |
| `SMTP_STARTTLS` | `1` | STARTTLS |
| `SMTP_SSL` | `0` | TLS implicite (prioritaire) |
| `SMTP_ALLOW_PLAINTEXT` | `0` | dérogation relais interne |
| `TOKEN_TTL_HOURS` | `72` | durée de vie des liens **et** des demandes en attente |
| `API_KEYS` | `dev-api-key` si DEBUG | clés API externes (CSV) |
| `SUPERADMIN_EMAILS` | — | source de vérité des superadmins [AUTH-9] |
| `SEED_ON_STARTUP` | `0` | jeu de démo (DEBUG uniquement) |
| `PORT` | `8000` | écoute |
| `FORWARDED_ALLOW_IPS` | — | proxys de confiance (uvicorn `--proxy-headers`) |

- [CFG-1] Toute valeur invalide est refusée **au démarrage** avec un message précis
  (fail fast) ; voir [SEC-8]/[SEC-9] pour les règles hors DEBUG.

---

## 11. Persistance et démarrage

- [DB-1] Schéma identique SQLite/PostgreSQL, créé automatiquement au démarrage
  (`create_all`) + **micro-migrations additives** : ajout de colonnes manquantes, et
  création de l'index unique partiel [DATA-2] sur les bases existantes (échec toléré si
  doublons historiques : avertissement, pas de crash).
- [DB-2] **Migration d'héritage** : l'ancien flag global `teams.requires_validation`
  (obsolète mais conservé dans le schéma) est repris **une seule fois**, à la création
  de la table des règles : chaque équipe qui était en auto le devient **pour chaque
  produit existant**.
- [DB-3] Démarrage **multi-replicas** sûr : sur PostgreSQL, la création/migration du
  schéma est sérialisée par un verrou consultatif transactionnel (id constant).
- [DB-4] SQLite : `PRAGMA foreign_keys=ON`, `journal_mode=WAL` ;
  `sqlite:///:memory:` utilise un pool statique (tests). `pool_pre_ping` activé.
- [DB-5] L'insertion d'une demande traduit la violation de l'index partiel [DATA-2] en
  erreur « doublon » métier (soumissions simultanées → un seul 201, l'autre 409).

---

## 12. Jeu de démonstration (seed)

Exécuté par `SEED_ON_STARTUP=1` (DEBUG) ou `python -m app.seed` (refusé hors DEBUG).
**Idempotent** : relançable sans doublon ; ne modifie jamais un réglage changé via
l'UI (les règles d'auto ne sont posées qu'à la **création** du produit).

- [SEED-1] Produits : `IBM BOB` (« Assistant IBM pour la modernisation du code »),
  `CLAUDE CODE` (« Agent de développement Anthropic en ligne de commande »), `DEVX`
  (« Plateforme interne d'expérience développeur »), `I4DEVA` (« Suite d'outils
  d'industrialisation pour les développeurs »).
- [SEED-2] 10 équipes : Team Backend, Frontend, Mobile, DevOps, Data, QA, Cloud,
  Securite, Architecture, Plateforme.
- [SEED-3] Auto-approbation **par produit** : Team QA en auto sur les 4 produits ;
  Team Plateforme en auto sur DEVX et I4DEVA uniquement.
- [SEED-4] SPOC (figures de l'informatique, `prenom.nom@example.com`) : 1 SPOC par
  équipe sur chaque produit, et un **second** SPOC par équipe sur CLAUDE CODE et DEVX
  (multi-SPOC). Paires par équipe : Backend (Grace Hopper, Dennis Ritchie), Frontend
  (Ada Lovelace, Brendan Eich), Mobile (Alan Turing, Margaret Hamilton), DevOps
  (Linus Torvalds, Gene Kim), Data (Edgar Codd, Hedy Lamarr), QA (Kent Beck, Lisa
  Crispin), Cloud (Werner Vogels, Diane Greene), Securite (Bruce Schneier, Katie
  Moussouris), Architecture (Martin Fowler, Barbara Liskov), Plateforme (Guido van
  Rossum, Anders Hejlsberg).
- [SEED-5] Comptes : `superadmin@example.com` (Sophie Superadmin, superadmin),
  `admin.bob@` (IBM BOB), `admin.claude@` (CLAUDE CODE), `admin.devx@` (DEVX),
  `admin.i4deva@` (I4DEVA), `dev.demo@` (Damien Demandeur). Le template par défaut est
  créé s'il n'existe pas.

---

## 13. Déploiement

- [DEP-1] Image Docker : python slim, dépendances installées, **utilisateur non-root
  numérique (10001)**, `HEALTHCHECK` sur `/healthz`, lancement uvicorn avec
  `--proxy-headers --no-server-header --timeout-graceful-shutdown 20`.
- [DEP-2] Manifests Kubernetes fournis pour deux options : **SQLite** (1 replica,
  `strategy: Recreate`, PVC monté sur `/data`) et **PostgreSQL** (2 replicas).
  Pods : `runAsNonRoot` + UID/GID 10001, `seccompProfile: RuntimeDefault`,
  `allowPrivilegeEscalation: false`, `readOnlyRootFilesystem: true` (+ `emptyDir` sur
  `/tmp`), `capabilities: drop ALL`, `automountServiceAccountToken: false`,
  readiness sur `/readyz`, liveness sur `/healthz`, requests/limits définis, secrets
  (`SECRET_KEY`, `API_KEYS`, `POSTGRES_PASSWORD`, `OIDC_CLIENT_SECRET`,
  `SMTP_PASSWORD`) en `Secret`, le reste en `ConfigMap` ; valeurs d'exemple
  « CHANGEZ-MOI » que l'application **refuse** ([SEC-8]).
- [DEP-3] `docker-compose.yml` de dev : option postgres (service + healthcheck) et
  profil sqlite.
- [DEP-4] Lancement dev local : un script fixe `DEBUG=1`, `SEED_ON_STARTUP=1`,
  `AUTH_MODE=dev`, `EMAIL_MODE=console` et démarre sur :8000.

---

## 14. Application compagnon : « Portail Demandeur » (démo E2E)

Application **séparée** (port 8001) qui joue le rôle du portail externe, pour tester
le système de bout en bout sans SMTP. Démo uniquement : pas d'authentification propre,
état en mémoire.

- [PORT-1] Page « Mes demandes » : stepper explicatif (soumettre → le SPOC reçoit un
  e-mail → la licence est attribuée), formulaire (nom, e-mail, **choix du produit en
  cartes radio avec logos**, équipe — les équipes en auto pour le produit sont
  signalées, justification) qui appelle `POST /api/requests` avec la clé d'API ;
  tableau des demandes soumises avec statut relu via `GET /api/requests/{id}` à chaque
  affichage ; messages distincts selon `auto_approved` ; bandeau si l'API est
  injoignable (503/réseau) avec formulaire désactivé.
- [PORT-2] Page « Boîte mail SPOC (simulée) » : liste des comptes SPOC ayant reçu des
  mails (avatars initiales), boîte de réception par compte, lecture d'un mail dans une
  iframe fidèle — alimentée par `GET /dev/outbox.json` du validator ; les boutons du
  mail ouvrent la vraie page `/validate/{token}` dans un nouvel onglet.
- [PORT-3] Le portail partage l'apparence (thèmes, tables, macros logos/avatars) via
  des copies synchronisées des fichiers statiques et macros.
- [PORT-4] Config : `SPOC_API_URL` (défaut http://localhost:8000), `SPOC_API_KEY`
  (défaut dev-api-key), `SPOC_PUBLIC_URL`.

---

## 15. Critères d'acceptation (scénarios de bench)

Chaque scénario est vérifiable automatiquement (HTTP/DB/HTML). L'environnement de test
de référence : `DEBUG=1`, base en mémoire, mails en console, seed chargé, clé d'API
`dev-api-key`.

### A. Workflow nominal
1. `POST /api/requests` (IBM BOB / Team Backend) → 201 `pending` ; un mail est capturé
   pour `grace.hopper@example.com` contenant `/validate/` et `decision=approve`.
2. CLAUDE CODE / Team Backend → **2 mails** (multi-SPOC), liens distincts mais même
   demande ; le premier POST de décision gagne, l'autre lien → 409 et page « déjà
   traitée ».
3. `GET /validate/{token}` n'altère rien (statut toujours `pending` après N GET).
4. POST approbation avec commentaire → page de confirmation ; `GET /api/requests/{id}`
   montre `approved`, `decided_by` = e-mail du SPOC, le commentaire ; une LicenseGrant
   existe ; le provisioner a été appelé une fois.
5. Refus → `rejected`, aucune licence.
6. Doublon en attente → 409 ; après refus/expiration, re-soumission possible.
7. Team QA (auto sur les 4 produits) → 201 immédiat `approved`,
   `auto_approved=true`, `decided_by=auto@spoc-validator.local`, **zéro mail**, licence
   créée. Une équipe en auto **sans aucun SPOC** fonctionne aussi.
8. Couple (produit, équipe) exigeant validation **sans SPOC** → 422, rien en base.
9. Même équipe : auto sur DEVX, validation sur IBM BOB (le mode est bien par produit).

### B. Liens et sécurité des décisions
10. Token forgé/altéré → 403 ; token > 1024 caractères → rejet immédiat.
11. Lien d'une demande A ne peut pas décider la demande B (jeton de demande vérifié).
12. Retirer un SPOC invalide ses liens en attente (page d'erreur explicite) ; les
    liens d'une demande déjà décidée restent consultables (état réel affiché).
13. Deux décisions concurrentes (CAS) → une seule décision, une seule licence.
14. Demande plus vieille que le TTL : vue `expired` (commentaire exact [WF-21]) via
    l'API et l'UI ; nouvelle soumission acceptée ; le lien du SPOC dit « expiré ».

### C. API
15. Sans `X-API-Key` → 401 sur les 4 endpoints ; sans aucune clé configurée → 503.
16. `/api/catalog` expose `auto_approval` par produit conformément au seed [SEED-3].
17. `/api/spocs?product=IBM BOB` : toutes les équipes, `requires_validation` exact,
    SPOC listés ; produit inconnu → 404.
18. Champs trop longs (nom 121, justification 2001…) → 400 ; nom avec `\n` → 400/refus
    avant tout envoi (anti injection d'en-tête).
19. Échec SMTP simulé → 502 et **aucune demande en base**.
20. Erreurs API en JSON ; erreurs UI en HTML (vérifier le Content-Type des 403/404).

### D. UI et droits
21. Anonyme sur `/` → 303 `/login` ; après login, retour sur la page demandée
    (`?next` interne uniquement — un chemin `//evil` retombe sur `/`).
22. `dev.demo@` : voit ses demandes ; 403 sur `/admin/products`, `/admin/teams`,
    `/superadmin`, imports/exports.
23. `admin.bob@` : accès IBM BOB (200) ; 403 sur CLAUDE CODE et sur
    `/admin/products/1/settings` (réservé superadmin) ; peut créer/renommer une équipe.
24. `superadmin@` : accès à tout ; crée un produit (303 vers ses **Paramètres**) ;
    l'édite ; nomme et révoque un admin (retour à la page d'origine via `next`).
25. CSRF : POST sans/mauvais `_csrf` → 403 (page « Session expirée » côté UI).
26. Onglet Demandes : filtre `?status=pending` + recherche `?q=` combinés, compteurs
    par statut corrects, pagination à 50 (51 demandes ⇒ 2 pages, bornage de `page`).
27. Équipes sans SPOC (validation requise) signalées sur la liste des produits,
    l'en-tête du produit et l'onglet Validation ; absentes si l'équipe est en auto.
28. Template : placeholder inconnu → erreur **et brouillon conservé** (status 400) ;
    corps sans lien de décision → refus ; reset → retour au défaut ; aperçu rendu sur
    données fictives ; preview isolée (CSP sandbox, aucun script).
29. Bascule du mode de validation : confirmation au passage en auto, flash contextuel,
    effet immédiat sur l'API ([API-6]) et uniquement sur ce produit.
30. En-têtes de sécurité présents sur `/login` et `/api/...` ([SEC-1], CSP [SEC-2]) ;
    statiques versionnés (`?v=`) et HTML `no-store` ; corps de 1,1 Mo → 413 (HTML pour
    l'UI, JSON pour l'API) ; `/healthz` 200 ; `/readyz` 503 base coupée.
31. Dates UI dans `APP_TIMEZONE` (une demande créée à 20:46 UTC s'affiche 21:46 à
    Paris en hiver).

### E. CSV
32. Export produit : BOM UTF-8, `;`, en-têtes exacts, lignes pour équipes sans SPOC,
    valeur `=...` neutralisée par apostrophe ; export global limité aux produits
    administrés, colonne Produit.
33. Import UTF-8 **et** Windows-1252/`,` acceptés ; alias d'en-têtes ; erreurs avec
    numéros de ligne ; > 2000 lignes refusé ; fichier > 500 ko refusé ; vide refusé.
34. Aperçu sans écriture, puis apply ; fichier erroné jamais appliqué ; remplacement
    limité aux équipes listées ; import global : ligne d'un produit non administré en
    erreur ; équipes inconnues créées une seule fois ; modes contradictoires → erreur.
35. Imports/exports soumis aux droits + CSRF.

### F. Configuration et robustesse
36. Hors DEBUG : chacune des configs interdites de [SEC-8] **empêche le démarrage**
    (message explicite) ; config production valide démarre.
37. `SUPERADMIN_EMAILS` : promotion + rétrogradation au démarrage ; liste vide sans
    effet.
38. Login LDAP : 5 échecs → blocage avec délai annoncé ; succès après expiration.
39. Le commit précède la réponse (une 201 n'est jamais suivie d'un rollback perdant la
    demande) ; l'échec du balayage d'expiration ne casse aucune page.
40. Migration d'héritage [DB-2] : une base ancienne avec `requires_validation=false`
    sur une équipe produit des règles d'auto **par produit** au premier démarrage.

---

## 16. Hors périmètre (assumé)

- Suppression de produits, d'équipes, de demandes ; purge RGPD.
- Notification e-mail du demandeur après décision (il consulte le portail/l'API).
- Relances/escalade si aucun SPOC ne répond (les demandes expirent), délégation.
- Intégration licensing réelle (le port est fourni, l'implémentation journalise).
- i18n (français uniquement), multi-tenant, API d'administration (UI seulement).
- Rate limiting global de l'API (une clé par intégration, confiance contractuelle).
